﻿with balance1400cte as ( 
  SELECT
      a1400.CustomerNumberII,sum(a1400.Balance) sum1400
  FROM [alco-140204v].[dbo].[vw_DepositsAll] a1400
  where a1400.AccountCategory = N'تسهیلات'
  group by a1400.CustomerNumberII)
  , balance1401cte as(
  SELECT 
      a1401.CustomerNumberII,sum(a1401.Balance) sum1401
  FROM [alco-140205].[dbo].[vw_DepositsAll] a1401
  where a1401.AccountCategory = N'تسهیلات'
  group by a1401.CustomerNumberII)
  select top 150 a1401.CustomerNumberII
 ,a1400.sum1400,a1401.sum1401,-coalesce(a1400.sum1400,0)+a1401.sum1401 diff
  into  [alco-14020626].[dbo].loan150I
   from balance1401cte a1401
   left join balance1400cte  a1400 on a1400.CustomerNumberII=a1401.CustomerNumberII
  -- where a1401.[شماره مشتري داخلي]= 9999011450
   order by -coalesce(a1400.sum1400,0)+a1401.sum1401 desc


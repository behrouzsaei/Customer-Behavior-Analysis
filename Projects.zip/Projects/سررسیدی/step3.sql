﻿select '14020925' as DateR,Name.[شماره مشتري خارجی],(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 into  [alco-14020925].[dbo].[III1]--savefile
 from [alco-14020925].[dbo].[vw_DepositsAll1] A 
 left join [alco-140208].dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
 left join [alco-140208].dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  where A.AccountCategory<> N'تسهیلات' and
   A.CustomerNumberII in 
(select [CustomerNumberII] from [alco-14020925].[dbo].[sarresidiF]
 )
--union all
 insert into  [alco-14020925].[dbo].[III1]--savefile
 select '140208' as DateR,Name.[شماره مشتري خارجی],(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه] 
 -- into [alco-14020618].dbo.ifoSarresidi2
 from [alco-140208].dbo.vw_DepositsAll A 
 left join [alco-140208].dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
  left join [alco-140208].dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(select [CustomerNumberII] from [alco-140208].[dbo].[sarresidiF])
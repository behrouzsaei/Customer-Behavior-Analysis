
  /****** Script for SelectTopNRows command from SSMS  ******/
SELECT top 20 [name]
   
	  ,sum([140208])
	  ,sum([140209])
	  ,sum([140209]-[140208]) [diff]
	  from [alco-14020925].[dbo].[sarresidi00]
group by [name]
order by [diff] asc
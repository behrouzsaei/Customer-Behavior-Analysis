SELECT 
      [CustomerNumberII]
      ,(coalesce([balance],0)) [140208]
      ,[InterestRate]
      ,[MaturityDate]
      ,[AccountCategory]
      ,[شرح مديريت شعب]
	  into [alco-14020925].[dbo].[saresidi08]
  FROM [alco-14020925].[dbo].[III3] 
  where [DateR]=140208


SELECT 
      [CustomerNumberII]
      ,(coalesce([balance],0)) [14020925]
      ,[InterestRate]
      ,[MaturityDate]
      ,[AccountCategory]
      ,[شرح مديريت شعب]
	  into [alco-14020925].[dbo].[saresidi09]
  FROM [alco-14020925].[dbo].[III3] 
  where [DateR]=14020925
  
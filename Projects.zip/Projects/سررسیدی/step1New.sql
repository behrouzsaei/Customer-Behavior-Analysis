﻿USE [alco-14020925]
GO

/****** Object:  Table [dbo].[sarresidiF]    Script Date: 1/3/2024 3:35:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[sarresidiF](
	[CustomerNumberII] [decimal](18, 0) NULL,
) ON [PRIMARY]
GO


INSERT INTO [alco-14020925].[dbo].[sarresidiF] 
SELECT 
     t.[CustomerNumberII]
FROM [alco-14020925].[dbo].[vw_DepositsAll1] t
WHERE (t.[AccountCategory] = N'گواهی سپرده' OR t.[AccountCategory] = N'بلند مدت') AND (t.[MaturityDate] BETWEEN 14020900 AND 14021000)
GROUP BY t.[CustomerNumberII]



USE [alco-140208]
GO

/****** Object:  Table [dbo].[sarresidiF]    Script Date: 1/3/2024 3:35:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[sarresidiF](
	[CustomerNumberII] [decimal](18, 0) NULL,
) ON [PRIMARY]
GO


INSERT INTO [alco-140208].[dbo].[sarresidiF] 
SELECT 
     t.[CustomerNumberII]
FROM [alco-140208].[dbo].[vw_DepositsAll] t
WHERE (t.[AccountCategory] = N'گواهی سپرده' OR t.[AccountCategory] = N'بلند مدت') AND (t.[MaturityDate] BETWEEN 14020900 AND 14021000)
GROUP BY t.[CustomerNumberII]
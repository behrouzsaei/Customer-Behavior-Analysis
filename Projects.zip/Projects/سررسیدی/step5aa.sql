﻿SELECT
    [AccountCategory],
    [state],
    SUM(CASE WHEN [state] = 'positive' THEN [balance140208] ELSE 0 END) AS [positive_balance140208],
    SUM(CASE WHEN [state] = 'positive' THEN [balance140209] ELSE 0 END) AS [positive_balance140209],
    SUM(CASE WHEN [state] = 'negative' THEN [balance140208] ELSE 0 END) AS [negative_balance140208],
    SUM(CASE WHEN [state] = 'negative' THEN [balance140209] ELSE 0 END) AS [negative_balance140209],
    SUM(CASE WHEN [state] = 'not change' THEN [balance140208] ELSE 0 END) AS [not_change_balance140208],
    SUM(CASE WHEN [state] = 'not change' THEN [balance140209] ELSE 0 END) AS [not_change_balance140209]
FROM
    (
        SELECT
            s.[CustomerNumberII],
            SUM(COALESCE(s.[140208], 0)) AS [balance140208],
            SUM(COALESCE(a.[14020925], 0)) AS [balance140209],
            s.[InterestRate],
            s.[AccountCategory],
            s.[شرح مديريت شعب],
            (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) AS [diff],
            CASE
                WHEN (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) > 0 THEN 'positive'
                WHEN (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) < 0 THEN 'negative'
                WHEN (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) = 0 THEN 'not change'
            END AS [state]
        FROM
            [alco-14020925].[dbo].[saresidi08] s
        LEFT JOIN
            [alco-14020925].[dbo].[saresidi09] a ON a.[CustomerNumberII] = s.[CustomerNumberII]
        GROUP BY
            s.[CustomerNumberII],
            s.[InterestRate],
            s.[AccountCategory],
            s.[شرح مديريت شعب]
    ) AS subquery
GROUP BY
    [AccountCategory],
    [state];
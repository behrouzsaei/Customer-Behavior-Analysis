SELECT
    s.[CustomerNumberII],
    SUM(COALESCE(s.[140208], 0)) AS [balance140208],
    SUM(COALESCE(a.[14020925], 0)) AS [balance140209],
    (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) AS [diff],
    CASE
        WHEN (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) > 0 THEN 'positive'
        WHEN (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) < 0 THEN 'negative'
        WHEN (SUM(COALESCE(a.[14020925], 0)) - SUM(COALESCE(s.[140208], 0))) = 0 THEN 'not change'
    END AS [state],
    s.[InterestRate],
    s.[AccountCategory],
    s.[شرح مديريت شعب]
FROM
    [alco-14020925].[dbo].[saresidi08] s
LEFT JOIN
    [alco-14020925].[dbo].[saresidi09] a ON a.[CustomerNumberII] = s.[CustomerNumberII]
GROUP BY
    s.[CustomerNumberII],
    s.[InterestRate],
    s.[AccountCategory],
    s.[شرح مديريت شعب];
﻿with balance1400cte as ( 
  SELECT
      a1400.CustomerNumberII,sum(a1400.Balance) sum1400,a1400.AccountCategory
  FROM [alco-14020925].[dbo].[vw_DepositsAll1] a1400
  where a1400.AccountCategory <> N'تسهیلات' AND  a1400.CustomerNumberII in 
(select [CustomerNumberII] from [alco-14020925].[dbo].[sarresidiF]
 )


  group by a1400.CustomerNumberII,a1400.AccountCategory)
  , balance1401cte as(
  SELECT 
      a1401.CustomerNumberII,sum(a1401.Balance) sum1401,a1401.AccountCategory
  FROM [alco-140208].[dbo].[vw_DepositsAll] a1401
  where a1401.AccountCategory <> N'تسهیلات' AND  a1401.CustomerNumberII in 
(select [CustomerNumberII] from [alco-140208].[dbo].[sarresidiF]
 )

  group by a1401.CustomerNumberII,a1401.AccountCategory)
  select a1401.CustomerNumberII ,a1400.AccountCategory
 ,a1400.sum1400,a1401.sum1401,-coalesce(a1400.sum1400,0)+a1401.sum1401 diff
  --into  [alco-14020626].[dbo].loan150I
   from balance1401cte a1401
   left join balance1400cte  a1400 on a1400.CustomerNumberII=a1401.CustomerNumberII
  -- where a1401.[شماره مشتري داخلي]= 9999011450
  -- order by -coalesce(a1400.sum1400,0)+a1401.sum1401 desc


/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [AccountCategory],[InterestRate],sum([Balance]) [Balance],left([MaturityDate],6) [MaturityDate],[CustomerNumberII]
  FROM [alco-14020925].[dbo].[vw_DepositsAll1]
  where (left([MaturityDate],6)>140208 )
  group by [InterestRate],[AccountCategory],[MaturityDate],[CustomerNumberII]
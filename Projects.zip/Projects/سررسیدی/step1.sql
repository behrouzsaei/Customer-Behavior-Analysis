﻿USE [alco-14020925]
GO

/****** Object:  Table [dbo].[sarresidiF]    Script Date: 1/3/2024 3:35:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[sarresidiF](
	[AccountCategory] [nvarchar](11) NOT NULL,
	[CustomerNumberII] [decimal](18, 0) NULL,
	[InterestRate] [float] NULL,
	[شرح مديريت شعب] [varchar](100) NULL,
	[MaturityDate] [int] NULL,
	[Balance] [float] NULL
) ON [PRIMARY]
GO


INSERT INTO [alco-14020925].[dbo].[sarresidiF] 
SELECT 
     t.[AccountCategory],
     t.[CustomerNumberII],
     t.[InterestRate],
     o.[شرح مديريت شعب],
     t.[MaturityDate],
     SUM([Balance]) AS [Balance]
FROM [alco-14020925].[dbo].[vw_DepositsAll1] t
LEFT JOIN [alco-140208].dbo.[اطلاعات شعب] o ON o.[كد شعبه] = t.[BranchCode]
WHERE (t.[AccountCategory] = N'گواهی سپرده' OR t.[AccountCategory] = N'بلند مدت') AND (t.[MaturityDate] BETWEEN 14020900 AND 14021000)
GROUP BY t.[AccountCategory],
         t.[CustomerNumberII],
         t.[InterestRate],
         t.[MaturityDate],
         o.[شرح مديريت شعب]

USE [alco-140208]
GO

/****** Object:  Table [dbo].[sarresidiF]    Script Date: 1/3/2024 3:35:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[sarresidiF](
	[AccountCategory] [nvarchar](11) NOT NULL,
	[CustomerNumberII] [decimal](18, 0) NULL,
	[InterestRate] [float] NULL,
	[شرح مديريت شعب] [varchar](100) NULL,
	[MaturityDate] [int] NULL,
	[Balance] [float] NULL
) ON [PRIMARY]
GO



INSERT INTO [alco-140208].[dbo].[sarresidiF] 
SELECT 
     t.[AccountCategory],
     t.[CustomerNumberII],
     t.[InterestRate],
     o.[شرح مديريت شعب],
     t.[MaturityDate],
     SUM([Balance]) AS [Balance]
FROM [alco-140208].[dbo].[vw_DepositsAll] t
LEFT JOIN [alco-140208].dbo.[اطلاعات شعب] o ON o.[كد شعبه] = t.[BranchCode]
WHERE (t.[AccountCategory] = N'گواهی سپرده' OR t.[AccountCategory] = N'بلند مدت') AND (t.[MaturityDate] BETWEEN 14020900 AND 14021000)
GROUP BY t.[AccountCategory],
         t.[CustomerNumberII],
         t.[InterestRate],
         t.[MaturityDate],
         o.[شرح مديريت شعب]

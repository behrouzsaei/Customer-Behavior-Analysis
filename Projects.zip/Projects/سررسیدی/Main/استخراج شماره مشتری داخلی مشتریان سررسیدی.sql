﻿/****** Script for SelectTopNRows command from SSMS  ******/
SELECT
      [CustomerNumberII]
  INTO [alco-140209].[dbo].[sarresidiF]
  FROM [alco-140208].[dbo].[vw_DepositsAll]
  WHERE AccountCategory <> N'تسهیلات' AND [MaturityDate] BETWEEN 14020900 AND 14020932
  GROUP BY [CustomerNumberII]

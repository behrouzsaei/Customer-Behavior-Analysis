﻿/****** Script for SelectTopNRows command from SSMS  ******/
SELECT
      [CustomerNumberII]
  INTO [alco-140302].[dbo].[sarresidiF]
  FROM [alco-140302].[dbo].[vw_DepositsAll]
  WHERE AccountCategory <> N'تسهیلات' AND [MaturityDate] BETWEEN 14030200 AND 14030232
  GROUP BY [CustomerNumberII]

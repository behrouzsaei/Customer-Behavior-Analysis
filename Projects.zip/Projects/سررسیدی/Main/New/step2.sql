﻿/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [AccountCategory],[InterestRate],sum([Balance]) [Balance],left([MaturityDate],6) [MaturityDate]
  FROM [alco-140302].[dbo].[vw_DepositsAll]
  where (left([MaturityDate],6)>140302 ) AND [AccountCategory]<>N'تسهیلات'
  group by [InterestRate],[AccountCategory],[MaturityDate]
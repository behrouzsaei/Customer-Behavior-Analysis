﻿USE [alco-140208]
GO

SELECT '140208' AS DateR, 
    (Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) AS Name,
    A.CustomerNumberII,
    SUM(A.Balance) AS Balance,
    A.InterestRate,
    A.AccountCategory COLLATE Arabic_CI_AS AS AccountCategory,
    i.[شرح مديريت شعب],
    i.[شرح ناحيه]
--INTO [alco-14020925].[dbo].[SarresidiTotalInfo]
FROM [alco-140208].dbo.vw_DepositsAll A 
LEFT JOIN [alco-140208].dbo.[اسم مشتريان] Name ON Name.[شماره مشتري داخلي] = A.CustomerNumberII
LEFT JOIN [alco-140208].dbo.[اطلاعات شعب] i ON i.[كد شعبه] = a.BranchCode
WHERE A.AccountCategory <> N'تسهیلات' 
    AND A.CustomerNumberII IN (
        SELECT [CustomerNumberII] FROM [alco-140209].[dbo].[SarresidiCustomer] n
    )
GROUP BY A.CustomerNumberII, A.InterestRate, A.MaturityDate, A.AccountCategory, A.BranchCode, i.[شرح مديريت شعب], i.[شرح ناحيه], Name.نام, Name.[نام خانوادگي], Name.[نام سازمان]

--UNION ALL

SELECT '140209' AS DateR, 
    (Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) AS Name,
    A.CustomerNumberII,
    SUM(A.Balance) AS Balance,
    A.InterestRate,
    A.AccountCategory COLLATE Arabic_CI_AS AS AccountCategory,
    i.[شرح مديريت شعب],
    i.[شرح ناحيه]
FROM [alco-140209].dbo.vw_DepositsAll A 
LEFT JOIN [alco-140209].dbo.[اسم مشتريان] Name ON Name.[شماره مشتري داخلي] = A.CustomerNumberII
LEFT JOIN [alco-140209].dbo.[اطلاعات شعب] i ON i.[كد شعبه] = a.BranchCode
WHERE A.AccountCategory <> N'تسهیلات' 
     AND A.CustomerNumberII IN (
    SELECT [CustomerNumberII] FROM [alco-140209].[dbo].[SarresidiCustomer] n
)
GROUP BY A.CustomerNumberII, A.InterestRate, A.MaturityDate, A.AccountCategory, A.BranchCode, i.[شرح مديريت شعب], i.[شرح ناحيه], Name.نام, Name.[نام خانوادگي], Name.[نام سازمان]
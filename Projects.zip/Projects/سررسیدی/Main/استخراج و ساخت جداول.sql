﻿WITH Balance1400CTE AS ( 
    SELECT 
        a1400.CustomerNumberII, 
        SUM(a1400.Balance) AS sum1400, 
        a1400.InterestRate, 
        a1400.AccountCategory 
    FROM [alco-140301].[dbo].[vw_DepositsAll] a1400 
    WHERE a1400.AccountCategory <> N'تسهیلات' 
    AND a1400.CustomerNumberII IN (SELECT [CustomerNumberII] FROM [alco-140301].[dbo].[sarresidiF]) 
    GROUP BY a1400.CustomerNumberII, a1400.InterestRate, a1400.AccountCategory 
), 
Balance1401CTE AS ( 
    SELECT 
        a1401.CustomerNumberII, 
        SUM(a1401.Balance) AS sum1401, 
        a1401.InterestRate, 
        a1401.AccountCategory 
    FROM [alco-140302].[dbo].[vw_DepositsAll] a1401 
    WHERE a1401.AccountCategory <> N'تسهیلات' 
    AND a1401.CustomerNumberII IN (SELECT [CustomerNumberII] FROM [alco-140301].[dbo].[sarresidiF]) 
    GROUP BY a1401.CustomerNumberII, a1401.InterestRate, a1401.AccountCategory 
) 
SELECT 
    CASE 
        WHEN -COALESCE(b1400.sum1400, 0) + b1401.sum1401 = 0 THEN 'not change' 
        WHEN -COALESCE(b1400.sum1400, 0) + b1401.sum1401 > 0 THEN 'positive' 
        ELSE 'negative' 
    END AS state, 
    COUNT(DISTINCT b1401.CustomerNumberII) AS CustomerCount, 
    b1401.InterestRate, 
    b1401.AccountCategory, 
    SUM(-COALESCE(b1400.sum1400, 0) + b1401.sum1401) AS diff -- Calculate diff for each state 
--INTO [alco-140302].[dbo].SarresidiCustomer
FROM Balance1401CTE b1401 
LEFT JOIN Balance1400CTE b1400 ON b1400.CustomerNumberII = b1401.CustomerNumberII 
GROUP BY 
    CASE 
        WHEN -COALESCE(b1400.sum1400, 0) + b1401.sum1401 = 0 THEN 'not change' 
        WHEN -COALESCE(b1400.sum1400, 0) + b1401.sum1401 > 0 THEN 'positive' 
        ELSE 'negative' 
    END, 
    b1401.InterestRate, 
    b1401.AccountCategory
ORDER BY state;
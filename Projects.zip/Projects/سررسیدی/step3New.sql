SELECT 
    '14020925' AS DateR,
    A.CustomerNumberII as CustomerNumberII,
    sum(A.Balance) AS Balance,
    A.InterestRate as InterestRate,
    A.AccountCategory  as AccountCategory 
INTO [alco-14020925].[dbo].[III] --savefile 
FROM [alco-14020925].[dbo].[vw_DepositsAll1] A 
WHERE  
     A.CustomerNumberII IN (
        SELECT [CustomerNumberII] 
        FROM [alco-14020925].[dbo].[sarresidiF]
    ) 
GROUP BY A.CustomerNumberII, A.InterestRate,AccountCategory

--union all

INSERT INTO [alco-14020925].[dbo].[III] --savefile 
SELECT 
    '140208' AS DateR,
    A.CustomerNumberII as CustomerNumberII,
    sum(A.Balance) AS Balance,
    A.InterestRate as InterestRate,
    A.AccountCategory  as AccountCategory
-- INTO [alco-14020618].dbo.ifoSarresidi2 
FROM [alco-140208].dbo.vw_DepositsAll A 
WHERE A.CustomerNumberII IN (
        SELECT [CustomerNumberII] 
        FROM [alco-140208].[dbo].[sarresidiF]
    ) 
GROUP BY A.CustomerNumberII, A.InterestRate,AccountCategory
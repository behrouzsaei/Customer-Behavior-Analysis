﻿SELECT coalesce(T.[DateR],S.[DateR]) [DateR]
      ,coalesce([intcustid],[CustomerNumberII]) [intcustid]
      ,sum([bal_0720]) [bal_amar]
	  ,SUM(DISTINCT S.[Balance]) behsazan
	  ,(sum([bal_0720]) - SUM(DISTINCT S.[Balance])) diff
      ,coalesce(T.[شرح مديريت شعب],S.[شرح مديريت شعب]) [شرح مديريت شعب]
      ,coalesce(T.[شرح ناحيه],S.[شرح ناحيه]) [شرح ناحيه]
FROM [alco-14020729].[dbo].[amarData] T
LEFT JOIN (
      SELECT [DateR]
            ,[CustomerNumberII]
            ,[شرح مديريت شعب]
	        ,[شرح ناحيه]
            ,SUM([Balance]) [Balance]
      FROM [alco-14020729].[dbo].[mehrgan2]
      -- WHERE [DateR] = 14020720
      GROUP BY [DateR]
              ,[CustomerNumberII]
              ,[شرح مديريت شعب]
	          ,[شرح ناحيه]
  ) S ON (S.[DateR] = T.[DateR] AND S.[شرح مديريت شعب] = T.[شرح مديريت شعب] AND S.[شرح ناحيه] = T.[شرح ناحيه] AND S.[CustomerNumberII] = T.[intcustid])
  -- WHERE T.[DateR] = 14020720
GROUP BY COALESCE(T.[DateR], S.[DateR])
          ,COALESCE([intcustid], [CustomerNumberII])
          ,COALESCE(T.[شرح مديريت شعب], S.[شرح مديريت شعب]) 
          ,COALESCE(T.[شرح ناحيه], S.[شرح ناحيه])
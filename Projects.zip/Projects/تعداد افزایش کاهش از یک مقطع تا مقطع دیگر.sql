﻿/****** Script for SelectTopNRows command from SSMS  ******/
with bal140109 as(
SELECT  T.[CustomerNumberII] [CustomerNumberII], sum(T.balance) balance140109
	  ,E.[شرح مديريت شعب]
  FROM [Alco-140109].[dbo].[vw_DepositsAll] T
 left join [Alco-140109].dbo.[اطلاعات شعب] E on E.[كد شعبه]=T.BranchCode
   where T.AccountCategory <> N'تسهیلات'
 group by [CustomerNumberII] ,E.[شرح مديريت شعب]

 ),
 bal140012 as
 (
 select  T.[CustomerNumberII] [CustomerNumberII], sum(T.balance) balance140012
	  ,E.[شرح مديريت شعب]
  FROM [Alco-140012].[dbo].[vw_DepositsAll] T
 left join [Alco-140109].dbo.[اطلاعات شعب] E on E.[كد شعبه]=T.BranchCode
    where T.AccountCategory <> N'تسهیلات'
 group by [CustomerNumberII] ,E.[شرح مديريت شعب]
)
select m.[شرح مديريت شعب],m.Tdiff,count(m.Tdiff) Cdiff,sum(m.diff) balancediff
 into [Alco-140109].dbo.[IEnavahi]
 from(
 select bal140109.[شرح مديريت شعب]
,bal140109.CustomerNumberII,(bal140109.balance140109-bal140012.balance140012) as diff,
(
case when(bal140109.balance140109-bal140012.balance140012)>0 then 'imp'
when (bal140109.balance140109-bal140012.balance140012)=0 then 'no-change' else 'exp' end
) Tdiff

 --,row_number() over(order by (bal140109.balance140109-bal140012.balance140012) desc) 
 from bal140109  left join bal140012 on bal140012.CustomerNumberII=bal140109.CustomerNumberII and bal140012.[شرح مديريت شعب]=bal140109.[شرح مديريت شعب]

 --left join [Alco-140109].dbo.[اسم مشتريان] I on i.[شماره مشتري داخلي]=bal140109.CustomerNumberII
-- where row_number() over(partition by bal140109.[شرح مديريت شعب] order by (bal140109.balance140109-bal140012.balance140012) desc) <31
--group by bal140109.[شرح مديريت شعب]
--order by (bal140109.balance140109-bal140012.balance140012) desc
)as m
group by m.[شرح مديريت شعب],m.Tdiff
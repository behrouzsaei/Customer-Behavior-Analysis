﻿/****** Script for SelectTopNRows command from SSMS  ******/
SELECT  
    [AccountCategory], 
    SUM(CASE WHEN [Balance] >= [BlockedAmount] THEN  [BlockedAmount]
             WHEN [Balance] < [BlockedAmount] THEN  [Balance] 
             ELSE 0  
        END) AS TotalBalance 
FROM [alco-140212].[dbo].[vw_DepositsAll] 
WHERE [BlockedState] = 1 
GROUP BY [AccountCategory]; 

GO
SELECT   
    [AccountCategory],  
    COUNT(CASE WHEN [BlockedState] = 1 THEN 1 ELSE NULL END) AS BlockedStateCount, 
    SUM(CASE WHEN [Balance] >= [BlockedAmount] THEN [BlockedAmount]  
             WHEN [Balance] < [BlockedAmount] THEN  [Balance]
             ELSE 0   
        END) AS TotalBalance  
FROM [alco-140212].[dbo].[vw_DepositsAll]  
WHERE [BlockedState] = 1 
GROUP BY [AccountCategory];

GO


SELECT  
    [AccountCategory], 
    SUM(CASE WHEN [Balance] >= [BlockedAmount] THEN  [BlockedAmount]
             WHEN [Balance] < [BlockedAmount] THEN  [Balance] 
             ELSE 0  
        END) AS TotalBalance,
		A.[شرح علت انسداد]
FROM [alco-140212].[dbo].[vw_DepositsAll] 
LEFT JOIN [dbo].[حساب هاي مسدودي] A ON ([AccountNumber] = A.[شماره حساب])
WHERE [BlockedState] = 1 
GROUP BY [AccountCategory], A.[شرح علت انسداد]; 

﻿
use [alco-140206]
 go
select '14020706' as DateR,Name.[شماره مشتري خارجی],(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 into  [alco-14020715].dbo.mehrganF
 from [alco-14020708].dbo.vw_DepositsAll1 A 
 left join dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
 left join dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
--  where A.AccountCategory<> N'تسهیلات' and
   A.CustomerNumberII in 
(SELECT  CustomerNumberII[dbo]
  FROM [alco-14020715].[dbo].[CnM]
 )
--union all
 insert into  [alco-14020715].dbo.mehrganF
 select '14020720' as DateR,Name.[شماره مشتري خارجی],(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه] 
 -- into [alco-14020618].dbo.ifoSarresidi2
 from [alco-14020722].dbo.vw_DepositsAll1 A 
 left join dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
  left join dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(SELECT  CustomerNumberII
  FROM [alco-14020722].[dbo].[behrouz]
 )
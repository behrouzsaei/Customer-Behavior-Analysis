﻿/****** Script for SelectTopNRows command from SSMS  ******/
use alco9706
go
drop table  myschema.temptb1to6
go

SELECT  [تاریخ]
      ,[ردیف]
      ,[گروه مشتری]
      ,[زیر گروه مشتری]
      ,r.[کد کل]
      ,[شرح کد کل]
      ,[کد باجه]
      ,[شرح باجه]
      ,r.[کد شعبه]
      ,[شرح  شعبه]
      ,[کد حوزه]
      ,[شرح حوزه]
      ,[کد مدیریت شعب]
      ,[شرح مدیریت شعب]
      ,[کد استان]
      ,[شرح استان]
      ,[کد ناحیه]
      ,[شرح ناحیه]
      ,[مانده انتها]
      ,[sarfasl]
	  --,rep.[وضعیت حساب ],rep.[نوع عمليات درمحاسبه],rep.[نوع منبع بر مبنای ماندگاری]
      ,[sharh],j.sumbal sumbal,((case when sumbal>0 then [مانده انتها]/(sumbal) else NULL end)) nesbat
	 into myschema.temptb1to6
  FROM [alco9706].[dbo].[R$] r

--  left join alco9706.dbo.repoo rep on rep.کل=r.[کد کل]
  left join 
  (select k.[کد کل],k.[کد شعبه],sum(k.[مانده انتها]) sumbal from  alco9706.dbo.R$  k
  --left join alco9706.dbo.repoo re on re.کل=k.[کد کل] 
      where k.تاریخ <>'9707'
	  group by   k.[کد کل],k.[کد شعبه]-- order by k.[کد شعبه]
  )
  j on j.[کد شعبه]=r.[کد شعبه] and j.[کد کل]=r.[کد کل]
   where r.تاریخ <>'9707'

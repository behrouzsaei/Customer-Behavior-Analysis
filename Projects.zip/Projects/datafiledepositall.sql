﻿USE [alco-14020512]
GO

/****** Object:  View [dbo].[vw_DepositsAll1]    Script Date: 8/6/2023 4:02:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO











create view [dbo].[vw_DepositsAll1]
as

SELECT 
		DISTINCT[شماره حساب]					as AccountNumber
		,N'بلند مدت'						as AccountCategory

		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,[تاريخ سر رسيد]				as MaturityDate
		,NULL							as StateChangeDate		
		,''					as CustomerNumberE
		,[شماره مشتري]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,[جمع مبالغ مسدودي]				as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		
      FROM [dbo].[بلند مدت] 
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري]
 UNION ALL
 
 SELECT
 		DISTINCT[شماره حساب]					as AccountNumber
		,N'كوتاه مدت'					as AccountCategory

		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,NULL							as MaturityDate
		,NULL							as StateChangeDate										
		,''					as CustomerNumberE
				,[شماره مشتري]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,[جمع مبالغ مسدودي]				as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		
FROM [dbo].[كوتاه مدت] 
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري]  
UNION ALL

SELECT 
		DISTINCT[شماره حساب]					as AccountNumber
		,N'جاری'							as AccountCategory

		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,NULL							as MaturityDate
		,NULL							as StateChangeDate
		,''					as CustomerNumberE
				,[شماره مشتري]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,ISNULL([جمع مبالغ مسدودي],0)	as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		
FROM [dbo].[جاري] 
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري]
UNION ALL

SELECT
		DISTINCT[شماره حساب]					as AccountNumber
 		,N'قرض الحسنه'					as AccountCategory
		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,NULL							as MaturityDate
		,NULL							as StateChangeDate
		,''					as CustomerNumberE
				,[شماره مشتري]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,ISNULL([جمع مبالغ مسدودي],0)	as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
 		,NULL							as BlockedNumber
		,NULL						as KindOfState
FROM [dbo].[قرض الحسنه]     
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري]
UNION ALL

SELECT
		DISTINCT[شماره حساب]					as AccountNumber
		,N'هدف'							as AccountCategory
		,[كد شعيه]						as BranchCode
		,901							as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,[تاريخ سررسيد]					as MaturityDate
		,NULL							as StateChangeDate
		,''					as CustomerNumberE
				,[شماره مشتري]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		--,ISNULL([مانده متوسط],0)		as BalanceAvg
		-- مانده متوسط صفر ارسال می شود و به جای آن از مانده استفاده شده است.
		,ISNULL([مانده],0)				as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,ISNULL([جمع مبالغ مسدودي],0)	as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState
      FROM [dbo].[هدف]        
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري]
UNION ALL
SELECT 
		DISTINCT[شماره حساب]					as AccountNumber
		,N'گواهی'						as AccountCategory

		,[کد شعبه عامل]						as BranchCode
		,''					as AccountTypeCode
		,[تاریخ انتشار اوراق]					as OpeningDate
		,[تاریخ انتشار اوراق]+10000				as MaturityDate
		,NULL							as StateChangeDate		
		,[شماره مشتری خارجی]					as CustomerNumberE
		,[شماره مشتری داخلی]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتری داخلی])					as CustomerNumberI
		,[نرخ]						as InterestRate
		,NULL						as CurrencyCode
		,NULL				as ClosingDate
		,ISNULL([مبلغ],0)		as BalanceAvg
		,''			as GLCodeBeh
		,ISNULL([مبلغ],0)				as Balance
		,NULL				as BlockedAmount
		,NULL					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		

 
     -- ,[نام مشتري]
    --  
     -- ,[شماره حساب]


  FROM [dbo].[گواهی]

         left join [Alco-9901].[dbo].BIG_U T on T.[CustomerNumberI]=[شماره مشتری داخلی]






GO



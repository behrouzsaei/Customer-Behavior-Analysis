﻿
use [alco-140206]
 go
select '140205' as DateR,(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 from [alco-140205].dbo.vw_DepositsAll A 
 left join [alco-140205].dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
 left join [alco-140205].dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(select  [CustomerNumberII]
from [alco-140206].[dbo].Deposit200 n
-- order by n.[مانده] desc
 )
union all
 select '140206' as DateR,(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 from [alco-140206].dbo.vw_DepositsAll A 
 left join [alco-140205].dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
  left join [alco-140205].dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(select [CustomerNumberII] from 
[alco-140206].[dbo].Deposit200 n
-- order by n.[مانده] desc
 )
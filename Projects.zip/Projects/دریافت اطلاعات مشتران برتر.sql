﻿
use [alco-14020701]
 go
select '140112' as DateR,(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 from [alco-140112].dbo.vw_DepositsAll A 
 left join [alco-140112].dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
 left join [alco-140112].dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(select  [CustomerNumberII] 
from [alco-14020701].[dbo].Bartar30 n
-- order by n.[مانده] desc
 )
union all
 select '140207' as DateR,(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 from [alco-14020701].dbo.vw_DepositsAll1 A 
 left join [alco-140112].dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
  left join [alco-140112].dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(select [CustomerNumberII] from 
[alco-14020701].[dbo].Bartar30 n
-- order by n.[مانده] desc
 )
﻿select [CustomerNumberII],N.[شرح ناحيه] from [alco-140105].dbo.vw_DepositsAll T
left join [alco-140105].dbo.[اطلاعات شعب] N on N.[كد شعبه] = T.[BranchCode]
where CustomerNumberII in (select [CustomerNumberII] from 
[alco-140105].[dbo].loan500) and [AccountCategory]=N'تسهیلات'
group by [CustomerNumberII],N.[شرح ناحيه]
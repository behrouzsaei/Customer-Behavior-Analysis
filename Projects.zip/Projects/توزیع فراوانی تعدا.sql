﻿use [alco-9912]
go

	SELECT '9912' as dateofm
		,count([CustomerNumberII]) ctC
      ,sum([Balance]) balance
  ,(
  case
	   when T.balance <500000000 then '01)0-500000000'
       when T.balance <3000000000 then '02)500000000-3000000000'
       when T.balance <10000000000 then '03)3000000000-10000000000'
       when T.balance <50000000000 then '04)10000000000-50000000000'
       when T.balance <100000000000 then '05)50000000000-100000000000'
       when T.balance <300000000000 then '06)100000000000-300000000000'
       when T.balance <500000000000 then  '07)300000000000-500000000000'
       when T.balance <1000000000000 then '08)500000000000-1000000000000'  
       when T.balance <3000000000000 then '09)1000000000000-3000000000000' 
       when T.balance <5000000000000 then '10)3000000000000-5000000000000' 
       else '11)5000000000000-end' end) as cate
	, i.نوع
  FROM (select w.CustomerNumberII,sum(w.Balance) balance from [dbo].[vw_DepositsAll] w
  where [AccountCategory]<>N'تسهیلات'  group by w.CustomerNumberII) T
  left join [dbo].[اسم مشتريان] i on i.[شماره مشتري داخلي]=t.CustomerNumberII
  group by 
  (
  case
	   when T.balance <500000000 then '01)0-500000000'
       when T.balance <3000000000 then '02)500000000-3000000000'
       when T.balance <10000000000 then '03)3000000000-10000000000'
       when T.balance <50000000000 then '04)10000000000-50000000000'
       when T.balance <100000000000 then '05)50000000000-100000000000'
       when T.balance <300000000000 then '06)100000000000-300000000000'
       when T.balance <500000000000 then  '07)300000000000-500000000000'
       when T.balance <1000000000000 then '08)500000000000-1000000000000'  
       when T.balance <3000000000000 then '09)1000000000000-3000000000000' 
       when T.balance <5000000000000 then '10)3000000000000-5000000000000' 
       else '11)5000000000000-end' end), i.نوع
﻿
use [alco-140207]
 go
select '14020820' as DateR,Name.[شماره مشتري خارجی],(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
 into  [Sepordeh].[dbo].[III]--savefile
 from [Sepordeh].[dbo].[vw_DepositsAll1] A 
 left join dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
 left join dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  where A.AccountCategory<> N'تسهیلات' and
   A.CustomerNumberII in 
(SELECT  CustomerNumberII
  FROM [Sepordeh].[dbo].[deposit150I]
 )
--union all
 insert into  [Sepordeh].dbo.[III]--savefile
 select '14020729' as DateR,Name.[شماره مشتري خارجی],(Name.نام+' '+Name.[نام خانوادگي]+' '+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه] 
 -- into [alco-14020618].dbo.ifoSarresidi2
 from [alco-140207].dbo.vw_DepositsAll A 
 left join dbo.[اسم مشتريان] Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
  left join dbo.[اطلاعات شعب] i on i.[كد شعبه]=a.BranchCode
  WHERE A.CustomerNumberII in 
(SELECT  CustomerNumberII
  FROM [Sepordeh].[dbo].[deposit150I]
 )
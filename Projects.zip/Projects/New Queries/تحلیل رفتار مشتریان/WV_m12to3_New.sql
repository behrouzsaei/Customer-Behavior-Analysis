USE [alco-14020526]
GO

/****** Object:  View [dbo].[vw_M12to3]    Script Date: 8/21/2023 11:24:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE view [dbo].[vw_M12to3]
as
  select 'boland' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[boland01]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'boland' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[boland02]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'bolandP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[bolandP01]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'bolandP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[bolandP02]
  group by [DateR],[AccountCategory]

  UNION ALL
  select 'kotah' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[kotah01]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'kotah' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[kotah02]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'kotahP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[kotahP01]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'kotahP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[kotahP02]
  group by [DateR],[AccountCategory]

  UNION ALL
  select 'gharz' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[gharz01]
  group by [DateR],[AccountCategory]
  union all
  select 'gharz' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[gharz02]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'gharzP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[gharzP01]
  group by [DateR],[AccountCategory]
  union all
  select 'gharzP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[gharzP02]
  group by [DateR],[AccountCategory]


  UNION ALL
  select 'govahi' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[govahi01]
  group by [DateR],[AccountCategory]
  union all
  select 'govahi' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[govahi02]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'govahiP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[govahiP01]
  group by [DateR],[AccountCategory]
  union all
  select 'govahiP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[govahiP02]
  group by [DateR],[AccountCategory]


  UNION ALL
  select 'jari' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[jari01]
  group by [DateR],[AccountCategory]
  union all
  select 'jari' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[jari02]
  group by [DateR],[AccountCategory]
  UNION ALL
  select 'jariP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[jariP01]
  group by [DateR],[AccountCategory]
  union all
  select 'jariP' as kind,[DateR],[AccountCategory],sum([Balance]) [Balance]
  from [dbo].[jariP02]
  group by [DateR],[AccountCategory]

GO



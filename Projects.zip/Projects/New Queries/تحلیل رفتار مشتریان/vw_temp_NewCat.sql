﻿USE [alco-14020526]
GO

/****** Object:  View [dbo].[vw_temp]    Script Date: 8/26/2023 3:00:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








CREATE view [dbo].[vw_temp]
as
SELECT   T1.[AccountCategory]
      ,T1.[CustomerNumberE]
      ,T1.[CustomerNumberII]
      ,T1.[CustomerNumberI]
      ,(coalesce(T1.[Balance],0)-coalesce(T2.[Balance],0)) diff
	  ,(case when (T1.[Balance]-coalesce(T2.[Balance],0))<0 then 'positive'
	  when (T1.[Balance]-coalesce(T2.[Balance],0))=0 then 'not-change'
	  else  'negative' end) cat
  FROM [dbo].[vw_DepositsAll3] T2
  full outer join [alco-140112].[dbo].[vw_DepositsAll3] T1 on T1.[CustomerNumberII]=T2.[CustomerNumberII] and T1.[AccountCategory]=T2.[AccountCategory]
  where T1.[AccountCategory]=N'كوتاه مدت' or T1.[AccountCategory]=N'قرض الحسنه'









GO



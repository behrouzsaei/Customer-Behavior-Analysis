﻿USE [alco-14020526]
GO

/****** Object:  View [dbo].[vw_temp12]    Script Date: 8/21/2023 8:05:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE view [dbo].[vw_temp12]
as
SELECT coalesce(T1.[AccountCategory],T2.[AccountCategory]) [AccountCategory]
      ,coalesce(T1.[CustomerNumberII],T2.[CustomerNumberII]) [CustomerNumberII]
	  ,coalesce(T1.[Balance],NULL) TB1,coalesce(T2.balance,NULL) TB2
      ,(coalesce(T1.[Balance],0)-coalesce(T2.[Balance],0)) diff
	  ,(case 
	  when (coalesce(T1.[Balance],0)-coalesce(T2.[Balance],0))<0 then 'negative'
	  when (coalesce(T1.[Balance],0)-coalesce(T2.[Balance],0))=0 then 'not-change'
	  else  'positive' end) cat
	  ,(case 
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<990000000 then '0-99'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<1500000000 then '99-150'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<300000000 then '150-300'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<10000000000 then '300-1000'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<50000000000 then '1000-5000'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<100000000000 then '5000-10000'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<500000000000 then '10000-50000'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<1000000000000 then '50000-100000'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<5000000000000 then '100000-500000'
	  when abs(-coalesce(T1.[Balance],0)+coalesce(T2.[Balance],0))<10000000000000 then '500000-1000000'
	  else  '1000000+' end) cat2
  FROM [alco-140112].[dbo].[vw_DepositsAll3] T2
  full outer join [dbo].[vw_DepositsAll3] T1 on (T1.[CustomerNumberII]=T2.[CustomerNumberII] and T1.[AccountCategory]=T2.[AccountCategory]
  )
  where (T1.[AccountCategory]=N'كوتاه مدت' or T1.[AccountCategory]=Null  or T1.[AccountCategory]=N'قرض الحسنه')
  or
  (T2.[AccountCategory]=N'كوتاه مدت' or T2.[AccountCategory]=Null  or T2.[AccountCategory]=N'قرض الحسنه')


GO



﻿
 DECLARE @db1 NVARCHAR(128);
 DECLARE @db2 NVARCHAR(128);
 DECLARE @operator NVARCHAR(128);
 DECLARE @TopCount INT;

 SET @db1 = 'alco-140204v'
 SET @db2 = 'alco-14020609'
 SET @operator = '<>'      --  (<>)با تسهیلات (=) یا بدون تسهیلات
 SET @TopCount = 150

 DECLARE @sql1 NVARCHAR(MAX);
	SET @sql1 = '

		with balance1400cte as ( 
		  SELECT
			  a1400.CustomerNumberII,sum(a1400.Balance) sum1400
		  FROM '+ QUOTENAME(@db1) + '.dbo.vw_DepositsAll AS a1400
		  where a1400.AccountCategory  ' + @operator + ' N''تسهیلات''
		  group by a1400.CustomerNumberII)
		  , balance1401cte as(
		  SELECT 
			  a1401.CustomerNumberII,sum(a1401.Balance) sum1401
		  FROM '+ QUOTENAME(@db2) + '.dbo.vw_DepositsAll1 AS a1401
		  where a1401.AccountCategory  ' + @operator + ' N''تسهیلات''
		  group by a1401.CustomerNumberII)
		  select top ' + CAST(@TopCount AS NVARCHAR(10)) + ' a1401.CustomerNumberII
		 ,a1400.sum1400,a1401.sum1401,-coalesce(a1400.sum1400,0)+a1401.sum1401 diff
		  into  '+ QUOTENAME(@db2) + '.dbo.Deposit150I
		   from balance1401cte a1401
		   left join balance1400cte  a1400 on a1400.CustomerNumberII=a1401.CustomerNumberII
		   order by -coalesce(a1400.sum1400,0)+a1401.sum1401 desc
'
EXEC sp_executesql @sql1;
﻿
 DECLARE @db1 NVARCHAR(128);
 DECLARE @db2 NVARCHAR(128);
 DECLARE @temp NVARCHAR(128);

 SET @db1 = 'alco-140204v'
 SET @db2 = 'alco-14020609'
 SET @temp = ' '
 			
DECLARE @sql1 NVARCHAR(MAX);
	SET @sql1 = ' 
	 			     
	select ''' + @db1 + ''' as DateR,(Name.نام +'''+(@temp)+'''+Name.[نام خانوادگي] +'''+(@temp)+'''+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
	 from '+ QUOTENAME(@db1) + '.dbo.vw_DepositsAll AS A
	 left join ' + QUOTENAME(@db1) + '.dbo.[اسم مشتريان] AS Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
	 left join ' + QUOTENAME(@db1) + '.dbo.[اطلاعات شعب] AS i on i.[كد شعبه]=a.BranchCode
	  WHERE A.CustomerNumberII in 
	(select  [CustomerNumberII] 
	from ' + QUOTENAME(@db2) + '.dbo.Deposit150I n
	-- order by n.[مانده] desc
	 )

	 UNION ALL

	select ''' + @db2 + ''' as DateR,(Name.نام+'''+(@temp)+'''+Name.[نام خانوادگي]+'''+(@temp)+'''+Name.[نام سازمان]) as Name,A.CustomerNumberII,A.Balance,A.AccountNumber,A.InterestRate,A.MaturityDate,A.AccountCategory collate Arabic_CI_AS AccountCategory,A.BranchCode,i.[شرح مديريت شعب],i.[شرح ناحيه]
	 from '+QUOTENAME(@db2) + '.dbo.vw_DepositsAll1 AS A
	 left join ' + QUOTENAME(@db1) + '.dbo.[اسم مشتريان] AS Name on Name.[شماره مشتري داخلي]= A.CustomerNumberII
	 left join ' + QUOTENAME(@db1) + '.dbo.[اطلاعات شعب] AS i on i.[كد شعبه]=a.BranchCode
	  WHERE A.CustomerNumberII in 
	(select  [CustomerNumberII] 
	from ' + QUOTENAME(@db2) + '.dbo.Deposit150E n
	-- order by n.[مانده] desc
	 )
'
EXEC sp_executesql @sql1;

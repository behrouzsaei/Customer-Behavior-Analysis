﻿WITH bal14027 AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, SUM(T.balance) AS balance140207, E.[شرح مديريت شعب]
    FROM [alco-14020701].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات'
    GROUP BY [CustomerNumberII], E.[شرح مديريت شعب]
),

CTE AS (
    SELECT I.نام + ' ' + I.[نام خانوادگي] + ' ' + I.[نام سازمان] AS name, bal140207.CustomerNumberII, bal140207.[شرح مديريت شعب], bal140207.balance140207 AS balance,
    ROW_NUMBER() OVER (PARTITION BY bal140207.[شرح مديريت شعب] ORDER BY bal140207.balance140207 DESC) AS row_num
    FROM bal14027 bal140207
    LEFT JOIN [alco-140205].dbo.[اسم مشتريان] I ON I.[شماره مشتري داخلي] = bal140207.CustomerNumberII
),
Top10Balances AS (
    SELECT [شرح مديريت شعب], name, balance, row_num
    FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY [شرح مديريت شعب] ORDER BY balance DESC) AS rn
        FROM CTE
    ) sub
    WHERE rn <= 10
),
SumBalances AS (
    SELECT [شرح مديريت شعب], SUM(balance) AS TotalBalance
    FROM CTE
    GROUP BY [شرح مديريت شعب]
)
SELECT Top10Balances.*, SumBalances.TotalBalance
FROM Top10Balances
INNER JOIN SumBalances ON Top10Balances.[شرح مديريت شعب] = SumBalances.[شرح مديريت شعب]
ORDER BY Top10Balances.[شرح مديريت شعب], Top10Balances.row_num;
﻿WITH CTE AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, T.AccountCategory, E.[شرح مديريت شعب]
    FROM [alco-14020512].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات'
    AND T.[MaturityDate] BETWEEN 14020600 AND 14020632
),

bal140205 AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, SUM(T.balance) AS balance140205, E.[شرح مديريت شعب]
    FROM [alco-14020512].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات' AND T.AccountCategory <> N'جاري' AND T.AccountCategory <> N'كوتاه مدت' AND T.AccountCategory <> N'قرض الحسنه'
    AND T.[CustomerNumberII] IN (SELECT CustomerNumberII FROM CTE)
    GROUP BY T.[CustomerNumberII], E.[شرح مديريت شعب]
),

bal140207 AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, SUM(T.balance) AS balance140207, E.[شرح مديريت شعب]
    FROM [alco-14020701].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات' AND T.AccountCategory <> N'جاري' AND T.AccountCategory <> N'كوتاه مدت' AND T.AccountCategory <> N'قرض الحسنه'
    AND T.[CustomerNumberII] IN (SELECT CustomerNumberII FROM CTE)
    GROUP BY T.[CustomerNumberII], E.[شرح مديريت شعب]
),

SumBalances AS (
    SELECT bal140205.[شرح مديريت شعب], SUM(bal140205.balance140205) AS TotalBalanceT1, SUM(bal140207.balance140207) AS TotalBalanceT2
    FROM bal140205
    LEFT JOIN bal140207 ON bal140207.CustomerNumberII = bal140205.CustomerNumberII AND bal140207.[شرح مديريت شعب] = bal140205.[شرح مديريت شعب]
    GROUP BY bal140205.[شرح مديريت شعب]
)
SELECT SumBalances.[شرح مديريت شعب], SumBalances.TotalBalanceT1, SumBalances.TotalBalanceT2
FROM SumBalances
ORDER BY SumBalances.[شرح مديريت شعب]
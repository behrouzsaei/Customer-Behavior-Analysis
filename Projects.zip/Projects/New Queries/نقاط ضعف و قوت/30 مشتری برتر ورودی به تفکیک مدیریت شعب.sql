﻿WITH bal14027 AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, SUM(T.balance) AS balance140207, E.[شرح مديريت شعب]
    FROM [alco-14020701].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات'
    GROUP BY [CustomerNumberII], E.[شرح مديريت شعب]
),
bal140205 AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, SUM(T.balance) AS balance140205, E.[شرح مديريت شعب]
    FROM [alco-140205].[dbo].[vw_DepositsAll] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات'
    GROUP BY [CustomerNumberII], E.[شرح مديريت شعب]
),
CTE AS (
    SELECT I.نام + ' ' + I.[نام خانوادگي] + ' ' + I.[نام سازمان] AS name, bal140207.CustomerNumberII, bal140207.[شرح مديريت شعب], -COALESCE(bal140205.balance140205, 0) + bal140207.balance140207 AS diff, bal140207.balance140207, bal140205.balance140205,
    ROW_NUMBER() OVER (PARTITION BY bal140207.[شرح مديريت شعب] ORDER BY -COALESCE(bal140205.balance140205, 0) + bal140207.balance140207 DESC) AS row_num
    FROM bal14027 bal140207
    LEFT JOIN bal140205 ON bal140205.CustomerNumberII = bal140207.CustomerNumberII AND bal140205.[شرح مديريت شعب] = bal140207.[شرح مديريت شعب]
    LEFT JOIN [alco-140205].dbo.[اسم مشتريان] I ON I.[شماره مشتري داخلي] = bal140207.CustomerNumberII
),
SumDiffBalances AS (
    SELECT [شرح مديريت شعب], SUM(CTE.balance140207 - CTE.balance140205) AS TotalDiffBalance
    FROM CTE
    WHERE CTE.balance140207 - CTE.balance140205 > 0
    GROUP BY [شرح مديريت شعب]
)
SELECT CTE.*, SumDiffBalances.TotalDiffBalance
FROM CTE
INNER JOIN SumDiffBalances ON CTE.[شرح مديريت شعب] = SumDiffBalances.[شرح مديريت شعب]
WHERE CTE.row_num <= 30;
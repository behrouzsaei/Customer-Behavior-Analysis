﻿WITH bal140206 AS (
    SELECT E.[شرح مديريت شعب], SUM(T.balance) AS balance140206
    FROM [alco-14020512].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE (T.[MaturityDate] BETWEEN 14020600 AND 14020632) AND T.AccountCategory <> N'تسهیلات'
    GROUP BY E.[شرح مديريت شعب]
),
bal1402 AS (
    SELECT E.[شرح مديريت شعب], SUM(T.balance) AS balance1402
    FROM [alco-14020512].[dbo].[vw_DepositsAll1] T
    LEFT JOIN [alco-140205].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE (T.[MaturityDate] IS NOT NULL) AND T.AccountCategory <> N'تسهیلات'
    GROUP BY E.[شرح مديريت شعب]
)
SELECT COALESCE(bal140206.[شرح مديريت شعب], bal1402.[شرح مديريت شعب]) AS [شرح مديريت شعب],
       COALESCE(bal140206.balance140206, 0) AS total_balance140206,
       COALESCE(bal1402.balance1402, 0) AS total_balance1402
FROM bal140206
FULL JOIN bal1402 ON bal1402.[شرح مديريت شعب] = bal140206.[شرح مديريت شعب]
ORDER BY [شرح مديريت شعب];
﻿WITH bal140212 AS (
    SELECT T.[CustomerNumberII] AS CustomerNumberII, SUM(T.balance) AS balance140212, E.[شرح مديريت شعب]
    FROM [alco-140212].[dbo].[vw_DepositsAll] T
    LEFT JOIN [alco-140212].dbo.[اطلاعات شعب] E ON E.[كد شعبه] = T.BranchCode
    WHERE T.AccountCategory <> N'تسهیلات'
    GROUP BY [CustomerNumberII], E.[شرح مديريت شعب]
),

CTE AS (
    SELECT I.نام + ' ' + I.[نام خانوادگي] + ' ' + I.[نام سازمان] AS name, bal140212.CustomerNumberII, bal140212.[شرح مديريت شعب], bal140212.balance140212 AS balance,
    ROW_NUMBER() OVER (PARTITION BY bal140212.[شرح مديريت شعب] ORDER BY bal140212.balance140212 DESC) AS row_num
    FROM bal140212 bal140212
    LEFT JOIN [alco-140212].dbo.[اسم مشتريان] I ON I.[شماره مشتري داخلي] = bal140212.CustomerNumberII
),
Top30Balances AS (
    SELECT [شرح مديريت شعب], name, balance, row_num
    FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY [شرح مديريت شعب] ORDER BY balance DESC) AS rn
        FROM CTE
    ) sub
    WHERE rn <= 30
),
SumBalances AS (
    SELECT [شرح مديريت شعب], SUM(balance) AS TotalBalance
    FROM CTE
    GROUP BY [شرح مديريت شعب]
)
SELECT Top30Balances.*, SumBalances.TotalBalance
FROM Top30Balances
INNER JOIN SumBalances ON Top30Balances.[شرح مديريت شعب] = SumBalances.[شرح مديريت شعب]
ORDER BY Top30Balances.[شرح مديريت شعب], Top30Balances.row_num;
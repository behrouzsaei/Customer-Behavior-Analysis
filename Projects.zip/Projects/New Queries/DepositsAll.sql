﻿USE [alco-140206]
GO

/****** Object:  View [dbo].[vw_DepositsAll]    Script Date: 11/6/2023 9:14:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER view [dbo].[vw_DepositsAll]
as

SELECT 
		DISTINCT[شماره حساب]					as AccountNumber
		,N'بلند مدت'						as AccountCategory

		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,[تاريخ سر رسيد]				as MaturityDate
		,NULL							as StateChangeDate		
		,[شماره مشتري خارجي]					as CustomerNumberE
		,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,[جمع مبالغ مسدودي]				as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		
      FROM [dbo].[بلند مدت] 
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري داخلي]
 UNION ALL
 
 SELECT
 		DISTINCT[شماره حساب]					as AccountNumber
		,N'كوتاه مدت'					as AccountCategory

		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,NULL							as MaturityDate
		,NULL							as StateChangeDate										
		,[شماره مشتري خارجي]					as CustomerNumberE
				,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,[جمع مبالغ مسدودي]				as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		
FROM [dbo].[كوتاه مدت] 
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري داخلي]  
UNION ALL

SELECT 
		DISTINCT[شماره حساب]					as AccountNumber
		,N'جاری'							as AccountCategory

		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,NULL							as MaturityDate
		,NULL							as StateChangeDate
		,[شماره مشتري خارجي]					as CustomerNumberE
				,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,ISNULL([جمع مبالغ مسدودي],0)	as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		
FROM [dbo].[جاري] 
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري داخلي]
UNION ALL

SELECT
		DISTINCT[شماره حساب]					as AccountNumber
 		,N'قرض الحسنه'					as AccountCategory
		,[كد شعبه]						as BranchCode
		,[كد نوع حساب]					as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,NULL							as MaturityDate
		,NULL							as StateChangeDate
		,[شماره مشتري خارجي]					as CustomerNumberE
				,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		,ISNULL([مانده متوسط],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,ISNULL([جمع مبالغ مسدودي],0)	as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
 		,NULL							as BlockedNumber
		,NULL						as KindOfState
FROM [dbo].[قرض الحسنه]     
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري داخلي]
UNION ALL

SELECT
		DISTINCT[شماره حساب]					as AccountNumber
		,N'هدف'							as AccountCategory
		,[كد شعيه]						as BranchCode
		,901							as AccountTypeCode
		,[تاريخ افتتاح]					as OpeningDate
		,[تاريخ سررسيد]					as MaturityDate
		,NULL							as StateChangeDate
		,[شماره مشتري خارجي]					as CustomerNumberE
				,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[كد ارز]						as CurrencyCode
		,[تاريخ بسته شدن]				as ClosingDate
		--,ISNULL([مانده متوسط],0)		as BalanceAvg
		-- مانده متوسط صفر ارسال می شود و به جای آن از مانده استفاده شده است.
		,ISNULL([مانده],0)				as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,ISNULL([جمع مبالغ مسدودي],0)	as BlockedAmount
		,[وضعيت مسدودي]					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState
      FROM [dbo].[هدف]        
      left join [Alco-9901].[dbo].BIG_U T on T.CustomerNumberI=[شماره مشتري داخلي]
UNION ALL
SELECT 
DISTINCT[شماره گواهي]					as AccountNumber
		,N'گواهی سپرده'						as AccountCategory

		,[شعبه]						as BranchCode
		,[کد انتشار]					as AccountTypeCode
		,[سال انتشار]					as OpeningDate
		,[سال انتشار]+1				as MaturityDate
		,NULL							as StateChangeDate		
		,NULL					as CustomerNumberE
		,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ]						as InterestRate
		,NULL						as CurrencyCode
		,NULL				as ClosingDate
		,ISNULL([مانده ريال],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده ريال],0)				as Balance
		,NULL				as BlockedAmount
		,NULL					as BlockedState
		,NULL							as BlockedNumber
		,NULL						as KindOfState		

 
     -- ,[نام مشتري]
    --  
     -- ,[شماره حساب]


  FROM [dbo].[گواهی سپرده-جدید]

         left join [Alco-9901].[dbo].BIG_U T on T.[CustomerNumberI]=[شماره مشتري داخلي]
		     where (left([كد سرفصل حسابداري],4)=4241 or left([كد سرفصل حسابداري],4)=4243)
UNION ALL
SELECT 

		DISTINCT (Q.[شماره قرارداد])					as AccountNumber
		,N'تسهیلات'						as AccountCategory
		,[كد شعبه]						as BranchCode
		,[كد نوع تسهيلات]					as AccountTypeCode
		,[تاريخ قرارداد]					as OpeningDate
		,[تاريخ پايان قرارداد]				as MaturityDate
		,NULL							as StateChangeDate		
		,NULL					as CustomerNumberE
		,[شماره مشتري داخلي]					as CustomerNumberII
		,isnull(T.[کد یونیک],[شماره مشتري داخلي])					as CustomerNumberI
		,[نرخ سود]						as InterestRate
		,[توضيح کد سرفصل2]						as CurrencyCode
		,NULL				as ClosingDate
		,ISNULL([مانده],0)		as BalanceAvg
		,[كد سرفصل حسابداري]			as GLCodeBeh
		,ISNULL([مانده],0)				as Balance
		,NULL				as BlockedAmount
		,NULL				as BlockedState
		,s.[مبلغ استمهال]							as BlockedNumber
		,[توضيح کد سرفصل1]					as KindOfState

	
 
    --  ,[مبلغ قرارداد]
   --   ,[مبلغ قسط]
   --   ,[تاريخ اولين قسط]
    --  ,[نرخ جريمه]
   --   ,[تعداد اقساط پرداخت شده]
   --   ,[تعداد اقساط]
  --    ,[فاصله اقساط]
  --    ,[نوع تقسيط]
   --   ,[حد اعتباري]
   --   ,[كد مرجع تصويب]
   --   ,[توضيح کد سرفصل1]
    --  ,[توضيح کد سرفصل2]
  --    ,[شرح نوع تقسيط]
      
		
      FROM (
	  SELECT  
      DISTINCT[شماره قرارداد]
      ,[كد شعبه]
      ,[شماره مشتري داخلي]
      ,[كد نوع تسهيلات]
      ,[مبلغ قرارداد]
      ,[مبلغ قسط]
      ,[تاريخ قرارداد]
      ,[تاريخ اولين قسط]
      ,[تاريخ پايان قرارداد]
      ,[كد ارز]
      ,[نرخ سود]
      ,[نرخ جريمه]
      ,[تعداد اقساط پرداخت شده]
      ,[تعداد اقساط]
      ,[فاصله اقساط]
      ,[نوع تقسيط]
      ,[حد اعتباري]
      ,[كد مرجع تصويب],[كد سرفصل حسابداري]
      ,sum([مانده]) [مانده]
      ,[شرح نوع تقسيط]
      ,[توضيح کد سرفصل2],[توضيح کد سرفصل1]
	  ,[وضعيت قرارداد]
  FROM [dbo].[قرارداد]
  group by [تاريخ]
      ,[شماره قرارداد]
      ,[كد شعبه]
      ,[شماره مشتري داخلي]
      ,[كد نوع تسهيلات]
      ,[مبلغ قرارداد]
      ,[مبلغ قسط]
      ,[تاريخ قرارداد]
      ,[تاريخ اولين قسط]
      ,[تاريخ پايان قرارداد]
      ,[كد ارز]
      ,[نرخ سود]
      ,[نرخ جريمه]
      ,[تعداد اقساط پرداخت شده],[كد سرفصل حسابداري]
      ,[تعداد اقساط]
      ,[فاصله اقساط]
      ,[نوع تقسيط]
      ,[حد اعتباري]
      ,[كد مرجع تصويب]
      ,[شرح نوع تقسيط]
	  ,[توضيح کد سرفصل2],[توضيح کد سرفصل1]
      ,[وضعيت قرارداد]) as Q
      left join [Alco-9901].[dbo].BIG_U T on T.[CustomerNumberI]=[شماره مشتري داخلي]
	   left join [dbo].[مبلغ استمهال-جدید] S ON S.[شماره قرارداد]=Q.[شماره قرارداد]





GO



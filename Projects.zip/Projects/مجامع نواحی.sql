﻿SELECT [AccountCategory],
(
CASE
		WHEN T.InterestRate<=4									THEN	'A) 0-4'
		WHEN T.InterestRate>4		AND	T.InterestRate<=8		THEN	'B) 4-8'
		WHEN T.InterestRate>8		AND	T.InterestRate<=12		THEN	'C) 8-12'
		WHEN T.InterestRate>12		AND	T.InterestRate<=16		THEN	'D) 12-16'
		WHEN T.InterestRate>16		AND	T.InterestRate<=20		THEN	'E) 16-20'
		WHEN T.InterestRate>20		AND	T.InterestRate<=22		THEN	'F) 20-22'
		WHEN T.InterestRate>22		AND	T.InterestRate<=24		THEN	'G) 22-24'
		WHEN T.InterestRate>24		AND	T.InterestRate<=26		THEN	'H) 24-26'
		WHEN T.InterestRate>26		AND	T.InterestRate<=28		THEN	'I) 26-28'
		WHEN T.InterestRate>28									THEN	'J) 28-30'			
	END) 
catI
,left(T.MaturityDate,6) maturityD,i.[شرح مديريت شعب],i.[شرح ناحيه]
	--	,count(distinct[AccountNumber]) ctA
	--	,count(distinct[CustomerNumberII]) ctC
      ,sum([Balance]) balance
  ,(CASE
		WHEN T.InterestRate<=10									THEN	'A) 0-10'
		WHEN T.InterestRate>10		AND	T.InterestRate<=15		THEN	'B) 10-15'
		WHEN T.InterestRate>15		AND	T.InterestRate<=18		THEN	'C) 15-18'
		WHEN T.InterestRate>18		AND	T.InterestRate<=20		THEN	'D) 18-20'
		WHEN T.InterestRate>20									THEN	'J) 20+'			
	END) as cateInt,a.[شرح نوع عقد]
  FROM [alco-140106].[dbo].[vw_DepositsAll] T
  left join [alco-140106].[dbo].[اطلاعات شعب] i on i.[كد شعبه]=t.BranchCode
  left join [alco-140106].[dbo].[انواع عقد تسهيلات] a on a.[کد نوع تسهيلات]=t.AccountTypeCode
  group by [AccountCategory],
  (
CASE
		WHEN T.InterestRate<=4									THEN	'A) 0-4'
		WHEN T.InterestRate>4		AND	T.InterestRate<=8		THEN	'B) 4-8'
		WHEN T.InterestRate>8		AND	T.InterestRate<=12		THEN	'C) 8-12'
		WHEN T.InterestRate>12		AND	T.InterestRate<=16		THEN	'D) 12-16'
		WHEN T.InterestRate>16		AND	T.InterestRate<=20		THEN	'E) 16-20'
		WHEN T.InterestRate>20		AND	T.InterestRate<=22		THEN	'F) 20-22'
		WHEN T.InterestRate>22		AND	T.InterestRate<=24		THEN	'G) 22-24'
		WHEN T.InterestRate>24		AND	T.InterestRate<=26		THEN	'H) 24-26'
		WHEN T.InterestRate>26		AND	T.InterestRate<=28		THEN	'I) 26-28'
		WHEN T.InterestRate>28									THEN	'J) 28-30'			
	END
	)
   ,left(T.MaturityDate,6),i.[شرح مديريت شعب],i.[شرح ناحيه],a.[شرح نوع عقد]

  ,(CASE
		WHEN T.InterestRate<=10									THEN	'A) 0-10'
		WHEN T.InterestRate>10		AND	T.InterestRate<=15		THEN	'B) 10-15'
		WHEN T.InterestRate>15		AND	T.InterestRate<=18		THEN	'C) 15-18'
		WHEN T.InterestRate>18		AND	T.InterestRate<=20		THEN	'D) 18-20'
		WHEN T.InterestRate>20									THEN	'J) 20+'			
	END) 